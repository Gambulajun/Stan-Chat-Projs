from flask import Flask, render_template, request, \
    redirect, url_for, session, send_file, flash
import pandas as pd
import numpy as np
from werkzeug.security import generate_password_hash, check_password_hash
import io
import os
import math
from functools import wraps
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Replace with a secure key

# Load the CSV data
data = pd.read_csv('data/outputs/2024_smart_schd_output_v1.3.csv')

# Get the list of unique audits with their details
audits_df = data[['Audit Number', 'Audit Title', 'SchedulingPhase', 'Audit Plan Year', 
                'Audit Principal Risk Types', 'Audit Risk Radar Themes', 
                'Primary GIA Audit Owner Team', 'Planned Audit Notification Date',
       'Planned Planning Start Date', 'Planned Planning End Date',
       'Planned Fieldwork Start Date', 'Planned Fieldwork End Date',
       'Planned Reporting Start Date', 'Planned Report Issuance Date']].drop_duplicates()
audits = audits_df.to_dict('records')

# Initialize utilization for employees, converting BankID to int
utilization = {int(emp_id): 0 for emp_id in data['PSID'].unique()}

# User credentials (for demonstration purposes)
users = {
    'admin': generate_password_hash('admin123'),
    # Add more users as needed
}
def calculate_business_days(start_date, end_date):
    date_range = np.arange(start_date, end_date + timedelta(days=1), dtype='datetime64[D]')
    business_days = np.is_busday(date_range)
    return np.sum(business_days)

@app.template_filter('datetime')
def datetime_filter(value, format='%Y-%m-%d'):
    return datetime.strptime(value, format)

app.jinja_env.filters['datetime'] = datetime_filter

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('You need to be logged in to access this page.', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            error = "Username and password are required."
        else:
            user_password_hash = users.get(username)
            if user_password_hash and check_password_hash(user_password_hash, password):
                session['username'] = username
                next_page = request.args.get('next')
                return redirect(next_page or url_for('select_audit'))
            else:
                error = "Invalid username or password"
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    return redirect(url_for('select_audit'))

@app.route('/select_audit')
@login_required
def select_audit():
    audit_number = request.args.get('audit_number')
    if audit_number:
        return redirect(url_for('view_resources', audit_number=str(audit_number)))
    else:
        if audits:
            first_audit_number = audits[0]['Audit Number']
            return redirect(url_for('view_resources', audit_number=str(first_audit_number)))
        else:
            flash('No audits available.', 'warning')
            return redirect(url_for('index'))


@app.route('/view_resources/<audit_number>', methods=['GET', 'POST'])
@login_required
def view_resources(audit_number):
    page = request.args.get('page', 1, type=int)
    per_page = 6

    project_data = data[data['Audit Number'] == str(audit_number)]
    if project_data.empty:
        return "No data found for the selected audit."

    audit_title = project_data['Audit Title'].iloc[0]
    employees = project_data.to_dict('records')

    selected_emp_ids = set(
        selection['PSID']
        for selection in session.get('selections', [])
        if selection['Audit Number'] == str(audit_number)
    )

    filtered_employees = []
    for emp in employees:
        emp_id = int(emp['PSID'])
        emp_utilization = utilization.get(emp_id, 0)
        emp['Utilization'] = emp_utilization
        emp['Utilization Percent'] = f"{(emp_utilization / 250) * 100:.2f}%"
        
        availability_from_date = datetime.strptime(emp['AvailabilityFrom'], '%m/%d/%Y')
        availability_to_date = datetime.strptime(emp['AvailabilityTo'], '%m/%d/%Y')
        emp['available_days'] = calculate_business_days(availability_from_date, availability_to_date)

        if emp_utilization < 210:
            emp['selected'] = emp_id in selected_emp_ids
            filtered_employees.append(emp)

    filtered_employees.sort(key=lambda x: x.get('SimilarityScore', 0), reverse=True)

    total_employees = len(filtered_employees)
    total_pages = math.ceil(total_employees / per_page)
    start = (page - 1) * per_page
    end = start + per_page
    paginated_employees = filtered_employees[start:end]

    if request.method == 'POST':
        selected_employees = request.form.getlist('selected_employees')
        roles = {emp_id: request.form.get(f'role_{emp_id}') for emp_id in selected_employees}
        phases = {emp_id: request.form.get(f'phase_{emp_id}') for emp_id in selected_employees}


        if 'selections' not in session:
            session['selections'] = []

        for emp_id in selected_employees:
            emp_id_int = int(emp_id)
            role = roles[emp_id]
            phase = phases[emp_id]
            available_days_str = request.form.get(f'available_days_{emp_id}')

            if available_days_str:
                try:
                    available_days = int(available_days_str)
                    utilization[emp_id_int] += available_days
                except ValueError as e:
                    print(f"Error parsing available days for employee ID {emp_id}: {e}")
            else:
                print(f"Available days are missing for employee ID {emp_id}")

            emp_data = next((emp for emp in filtered_employees if int(emp['PSID']) == emp_id_int), None)
            if emp_data:
                session['selections'].append({
                    'Audit Number': str(audit_number),
                    'Audit Title': str(audit_title),
                    'PSID': emp_id_int,
                    'RecommendedRole': str(role),
                    'SelectedPhase': str(phase),
                    'Utilization': int(utilization[emp_id_int])
                })

        session.modified = True
        return redirect(url_for('view_resources', audit_number=str(audit_number), page=page))

    return render_template(
        'view_resources.html',
        audits=audits,
        audit_number=str(audit_number),
        audit_title=audit_title,
        employees=paginated_employees,
        page=page,
        total_pages=total_pages
    )

@app.route('/download')
@login_required
def download_schedule():
    if 'selections' not in session or not session['selections']:
        return "No data to download."

    # Convert the session data into a DataFrame
    selections_df = pd.DataFrame(session['selections'])

    # Merge with employee data to get additional details
    employee_details = data[['PSID', 'FullName', 'JobTitle', 'CountryName', 'LocationCity']].drop_duplicates()
    # Ensure BankID is of type int for merging
    employee_details['BankID'] = employee_details['PSID'].astype(int)

    merged_df = selections_df.merge(employee_details, left_on='PSID', right_on='PSID', how='left')

    # Rearrange columns
    merged_df = merged_df[
        ['Audit Number', 'Audit Title', 'PSID', 'FullName', 'JobTitle', 'CountryName', 
            'LocationCity', 'RecommendedRole', 'SelectedPhase', 'Utilization']
    ]

    # Sort by Audit Number and BankID for better readability
    merged_df.sort_values(['Audit Number', 'PSID'], inplace=True)

    # Create an in-memory CSV file
    output = io.StringIO()
    merged_df.to_csv(output, index=False)
    output.seek(0)

    # Send the CSV file as a download
    return send_file(
        io.BytesIO(output.getvalue().encode()),
        mimetype='text/csv',
        as_attachment=True,
        download_name='scheduled_employees.csv'
    )

@app.route('/clear/<audit_number>')
@login_required
def clear_selections(audit_number):
    if 'selections' in session:
        try:
            #selections_df = pd.DataFrame(session['selections'])

            # Filter out selections for the current audit
            session['selections'] = [
                selection for selection in session['selections']
                if selection['Audit Number'] != str(audit_number)
            ]

            # Convert session selections to DataFrame

            session.modified = True

            # Reset utilization for employees in the current audit
            project_data = data[data['Audit Number'] == audit_number]
            emp_ids_in_audit = project_data['PSID'].astype(int).unique()

            for emp_id in emp_ids_in_audit:
                emp_id_int = int(emp_id)
                current_utilization = utilization.get(emp_id_int, 0)

                # Get available days from the selections DataFrame
                #available_days_str = project_data[project_data['PSID'] == emp_id]['Utilization'].values[0]
                #if available_days_str:
                try:
                    #available_days = int(available_days_str)
                    utilization[emp_id_int] = max(0, current_utilization - current_utilization)
                except ValueError as e:
                    print(f"Error parsing available days for employee ID {emp_id_int}: {e}")
                    flash(f"Invalid available days for employee ID {emp_id_int}.", 'danger')
                #else:
                #    print(f"Available days are missing for employee ID {emp_id_int}")
                #    flash(f"Available days are missing for employee ID {emp_id_int}.", 'warning')

        except Exception as e:
            print(f"Error resetting utilization for audit {audit_number}: {e}")
            flash(f"An error occurred while clearing selections for audit {audit_number}.", 'danger')

    return redirect(url_for('view_resources', audit_number=str(audit_number)))

if __name__ == '__main__':
    app.run(debug=True)
